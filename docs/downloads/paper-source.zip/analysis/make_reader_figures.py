"""Render reader-facing summaries without changing the frozen sample ledger."""
from pathlib import Path
import csv
import statistics
import re
from make_figures import (plt, grid, title, save, mean_ci, median_interval,
                          FIXED, GATED, WORKLOADS, WORKLOAD_LABELS, COLORS,
                          EPISODE_LABELS, INK, MUTED, GRID, TEAL, NAVY, Patch, Line2D)

PAPER=Path(__file__).resolve().parents[1]
FIG=PAPER/'figures'
def rows(name):
    with (PAPER/'data'/name).open(newline='') as stream:return list(csv.DictReader(stream))
paired=rows('primary-points.csv');arms=rows('qualified-arms.csv');episodes=rows('qualified-episodes.csv')
mean,lo,hi=mean_ci([float(r['delta_w'])*1000 for r in paired])
fig,ax=plt.subplots(figsize=(8,3.5));fig.subplots_adjust(left=.17,right=.96,bottom=.24,top=.74)
title(fig,'Scene gating saved 49.54 mW','Paired mean and 95% confidence interval; full ledger linked in the report.')
grid(ax,'x');ax.axvline(0,color=MUTED,linestyle='--',linewidth=1)
ax.hlines(0,lo,hi,color=INK,lw=3);ax.scatter(mean,0,marker='D',color=INK,s=65,zorder=3)
ax.text(mean,.24,f'{mean:.2f} mW',ha='center',fontweight='bold',color=INK)
ax.text(mean,-.29,f'95% CI {lo:.2f} to {hi:.2f} mW',ha='center',color=MUTED,fontsize=10)
ax.set(yticks=[0],yticklabels=['Mean'],ylim=(-.65,.65),xlim=(-56,2),xlabel='Scene-gated minus fixed mean input power (mW)')
save(fig,FIG,'01_paired_power')
workstats={}
fig,ax=plt.subplots(figsize=(8,3.8));fig.subplots_adjust(left=.275,right=.84,bottom=.17,top=.76)
title(fig,'Input power by workload','Diamonds show means; horizontal lines show 95% confidence intervals.')
grid(ax,'x')
for rank,arm in enumerate(WORKLOADS):
    m,l,h=mean_ci([float(r['mean_power_w'])*1000 for r in arms if r['arm']==arm]);workstats[arm]=(m,l,h)
    ax.hlines(rank,l,h,color=COLORS[arm],lw=2.25);ax.scatter(m,rank,color=COLORS[arm],marker='D',s=48,zorder=3)
    ax.text(1.03,rank,f'{m:.2f} mW',transform=ax.get_yaxis_transform(),ha='left',va='center',fontweight='bold',fontsize=9)
ax.set(yticks=range(4),yticklabels=[WORKLOAD_LABELS[a] for a in WORKLOADS],ylim=(3.55,-.55),xlim=(598,690),xticks=[600,620,640,660,680],xlabel='Time-weighted input power per 29-second playback (mW)')
save(fig,FIG,'02_workload_power')
fig,(cover,delay)=plt.subplots(1,2,figsize=(9.6,4.8),width_ratios=(1,1.28),sharey=True)
fig.subplots_adjust(left=.184,right=.963,bottom=.14,top=.73,wspace=.22)
title(fig,'Same face segments, slower response under gating','Both policies matched the same three of four clip segments; the far-outdoor segment was missed.')
for ax in (cover,delay):grid(ax,'x');ax.set_ylim(3.52,-.52)
delays={}
for rank,episode in enumerate(EPISODE_LABELS):
    for arm,offset in ((FIXED,-.19),(GATED,.19)):
        group=[r for r in episodes if r['arm']==arm and r['id']==episode]
        ds=[float(r['first_matched_face_ms'])/1000 for r in group if int(r['matched_faces'])]
        fraction=100*len(ds)/len(group);y=rank+offset
        cover.barh(y,fraction,height=.29,color=COLORS[arm],zorder=3)
        cover.text(fraction-2 if ds else 3,y,f'{fraction:.0f}%',color='white' if ds else COLORS[arm],va='center',ha='right' if ds else 'left',fontsize=8,fontweight='bold')
        if ds:
            m,l,h=median_interval(ds);delays[arm,episode]=(m,l,h)
            delay.hlines(y,l,h,color=COLORS[arm],lw=1.5);delay.scatter(m,y,marker='D',color=COLORS[arm],s=38,zorder=3)
    if episode=='far-outdoor':delay.text(.075,rank,'No matched detections',fontsize=8.7,color=MUTED,va='center')
cover.set(yticks=range(4),yticklabels=list(EPISODE_LABELS.values()),xlim=(-1.3,101),xticks=[0,20,40,60,80,100],xlabel='Matched face episodes (%)')
delay.set(xlim=(0,2.65),xticks=[0,.5,1,1.5,2,2.5],xlabel='Episode start to first match (s)');delay.tick_params(labelleft=False)
handles=[Patch(facecolor=COLORS[a],label=WORKLOAD_LABELS[a]) for a in (FIXED,GATED)]
handles.append(Line2D([],[],color=INK,marker='D',linestyle='-',markersize=5,label='Median and observed range'))
fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.061,.829),frameon=False,ncol=3,fontsize=9)
save(fig,FIG,'03_episode_coverage_latency')
fig,ax=plt.subplots(figsize=(7.6,3.5));fig.subplots_adjust(left=.19,right=.95,bottom=.17,top=.69)
title(fig,'Scene gating ran fewer inference stages','Work relative to the same fixed-pipeline baseline.');grid(ax,'x')
for rank,key in enumerate(('detector_calls','identity_runs')):
    baseline=sum(int(r[key]) for r in arms if r['arm']==FIXED)
    for arm,offset in ((FIXED,-.19),(GATED,.19)):
        value=100*sum(int(r[key]) for r in arms if r['arm']==arm)/baseline;y=rank+offset
        ax.barh(y,value,height=.29,color=COLORS[arm]);ax.text(value+2,y,f'{value:.1f}%',va='center',fontsize=9,color=COLORS[arm],fontweight='bold')
ax.set(yticks=[0,1],yticklabels=['Detector calls','Identity runs'],ylim=(1.56,-.56),xlim=(0,119),xlabel='Relative device calls (fixed = 100%)')
ax.legend(handles=[Patch(facecolor=COLORS[a],label=WORKLOAD_LABELS[a]) for a in (FIXED,GATED)],loc='upper left',bbox_to_anchor=(-.15,1.28),frameon=False,ncol=2,fontsize=9)
save(fig,FIG,'04_inference_work')
# Native PGFPlots equivalents need no image uploads in the existing Overleaf tree.
style=r'font=\footnotesize, tick label style={font=\footnotesize}, label style={font=\footnotesize}, axis lines=left, xmajorgrids=true, grid style={gray!20}, tick align=outside'
paired_tex=rf'''\begin{{tikzpicture}}
\begin{{axis}}[width=.92\linewidth,height=3.5cm,{style},xmin=-56,xmax=2,ymin=-.6,ymax=.6,ytick={{0}},yticklabels={{Mean}},xtick={{-50,-40,-30,-20,-10,0}},xlabel={{Scene-gated minus fixed input power (mW)}}]
\addplot[gray,dashed] coordinates {{(0,-.6)(0,.6)}};
\addplot[ink,very thick] coordinates {{({lo:.9f},0)({hi:.9f},0)}};
\addplot[only marks,mark=diamond*,ink] coordinates {{({mean:.9f},0)}};
\node[above,font=\footnotesize] at (axis cs:{mean:.9f},.08) {{${mean:.2f}$ mW}};
\end{{axis}}\end{{tikzpicture}}'''
work_tex=rf'''\begin{{tikzpicture}}
\begin{{axis}}[width=.90\linewidth,height=4.1cm,{style},xmin=598,xmax=690,ymin=-.5,ymax=3.5,ytick={{0,1,2,3}},yticklabels={{Scene-gated,Fixed,Detector only,Capture only}},xtick={{600,620,640,660,680}},xlabel={{Mean input power (mW)}}]
'''
for rank,arm in enumerate(WORKLOADS):
    m,l,h=workstats[arm];y=3-rank;color='gatedcolor' if arm==GATED else 'fixedcolor' if arm==FIXED else 'gray'
    work_tex+=rf'\addplot[{color},thick] coordinates {{({l:.9f},{y})({h:.9f},{y})}};'+'\n'
    work_tex+=rf'\addplot[only marks,mark=diamond*,{color}] coordinates {{({m:.9f},{y})}};'+'\n'
work_tex+=r'\end{axis}\end{tikzpicture}'
episode_tex=rf'''\begin{{minipage}}[t]{{.48\textwidth}}\centering
\begin{{tikzpicture}}\begin{{axis}}[width=.84\linewidth,height=5.1cm,{style},xmin=0,xmax=105,ymin=-.5,ymax=3.5,ytick={{0,1,2,3}},yticklabels={{Far wet lens,Near hallway,Medium hallway,Far outdoor}},xtick={{0,50,100}},xlabel={{Matched episodes (\%)}},legend style={{font=\footnotesize,at={{(.5,1.03)}},anchor=south,legend columns=2}}]
\addplot[xbar,bar width=4pt,bar shift=3pt,fill=fixedcolor,draw=fixedcolor] coordinates {{(100,0)(100,1)(100,2)(0,3)}};
\addlegendentry{{Fixed}}
\addplot[xbar,bar width=4pt,bar shift=-3pt,fill=gatedcolor,draw=gatedcolor] coordinates {{(100,0)(100,1)(100,2)(0,3)}};
\addlegendentry{{Scene-gated}}
\end{{axis}}\end{{tikzpicture}}\end{{minipage}}\hfill
\begin{{minipage}}[t]{{.47\textwidth}}\centering
\begin{{tikzpicture}}\begin{{axis}}[width=.95\linewidth,height=5.1cm,{style},xmin=0,xmax=2.65,ymin=-.5,ymax=3.5,ytick=\empty,xtick={{0,.5,1,1.5,2,2.5}},xlabel={{First matched face (s)}}]
'''
for rank,ep in enumerate(EPISODE_LABELS):
    for arm,offset,color in ((FIXED,.17,'fixedcolor'),(GATED,-.17,'gatedcolor')):
        if (arm,ep) not in delays:continue
        m,l,h=delays[arm,ep];y=3-rank+offset
        episode_tex+=rf'\addplot[{color},thick] coordinates {{({l:.9f},{y})({h:.9f},{y})}};'+'\n'
        episode_tex+=rf'\addplot[only marks,mark=diamond*,{color}] coordinates {{({m:.9f},{y})}};'+'\n'
episode_tex+=r'\node[font=\footnotesize] at (axis cs:1.3,3) {No matched face};\end{axis}\end{tikzpicture}\end{minipage}'
p=PAPER/'main.tex';s=p.read_text()
for name,code in (('01_paired_power',paired_tex),('02_workload_power',work_tex),('03_episode_coverage_latency',episode_tex)):
    pattern=r'\\includegraphics\[[^\n]*\]\{figures/'+name+r'\.pdf\}'
    begin=f"% BEGIN_READER_PLOT {name}"
    end=f"% END_READER_PLOT {name}"
    marked=begin+"\n"+code+"\n"+end
    s,count=re.subn(pattern,lambda m:marked,s)
    if count==0 and begin in s:
        s,count=re.subn(re.escape(begin)+r".*?"+re.escape(end),lambda m:marked,s,flags=re.S)
    if count==0:
        # Migrate the first native version produced before marker support.
        captions={"01_paired_power":r"\caption{Paired reduction", "02_workload_power":r"\caption{Observed input power", "03_episode_coverage_latency":r"\caption{Face coverage"}
        stop=s.index(captions[name]);figure=s.rfind(r"\begin{figure",0,stop);start=s.index(r"\centering",figure)+len(r"\centering")
        assert start>0
        s=s[:start]+"\n"+marked+"\n"+s[stop:]
        count=1
    assert count==1,(name,count)
if r'\definecolor{fixedcolor}' not in s:
    s=s.replace(r'\definecolor{rust}{HTML}{984830}',r'\definecolor{rust}{HTML}{984830}'+'\n'+r'\definecolor{fixedcolor}{HTML}{283F81}'+'\n'+r'\definecolor{gatedcolor}{HTML}{007C75}')
p.write_text(s)
print('Rendered four count-free figure pairs and embedded equivalent native plots in main.tex.')
